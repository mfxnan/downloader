#!/data/data/com.termux/files/usr/bin/bash

# ==========================================================
# REPOSTIUM SERVICE CONTROLLER (FOR TERMUX)
# Mendukung mode PM2 (direkomendasikan) atau tmux fallback
# ==========================================================

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR" || exit 1

ACTION="${1:-status}"

has_pm2() {
  command -v pm2 &>/dev/null
}

start_service() {
  echo "Menjalankan Repostium..."
  if has_pm2; then
    pm2 start ecosystem.config.js
    pm2 save
    echo "Layanan berhasil dijalankan via PM2."
  else
    echo "PM2 tidak ditemukan, menggunakan runner native (start-repostium.js) di tmux..."
    if ! command -v tmux &>/dev/null; then
      echo "Error: tmux tidak ditemukan! Install dengan: pkg install tmux -y"
      exit 1
    fi
    tmux has-session -t repostium 2>/dev/null && tmux kill-session -t repostium
    tmux new-session -d -s repostium "node start-repostium.js"
    echo "Layanan berjalan di latar belakang (tmux session: repostium)."
  fi
}

stop_service() {
  echo "Menghentikan Repostium..."
  if has_pm2; then
    pm2 stop ecosystem.config.js
  fi
  if command -v tmux &>/dev/null && tmux has-session -t repostium 2>/dev/null; then
    tmux kill-session -t repostium
  fi
  echo "Layanan dihentikan."
}

restart_service() {
  echo "Merestart Repostium..."
  if has_pm2; then
    pm2 restart ecosystem.config.js
  else
    stop_service
    sleep 1
    start_service
  fi
}

view_logs() {
  if has_pm2; then
    pm2 logs
  elif command -v tmux &>/dev/null && tmux has-session -t repostium 2>/dev/null; then
    tmux attach -t repostium
  else
    echo "Tidak ada session aktif."
  fi
}

update_and_deploy() {
  echo "Menjalankan Update & Deploy Otomatis..."
  if git rev-parse --is-inside-work-tree &>/dev/null; then
    echo "[1/3] Menarik perubahan kode (git pull)..."
    git pull
  fi

  echo "[2/3] Memeriksa & memasang dependensi (npm install)..."
  npm install --omit=dev

  echo "[3/3] Merestart layanan..."
  restart_service
  echo "Update selesai!"
}

case "$ACTION" in
  start)
    start_service
    ;;
  stop)
    stop_service
    ;;
  restart)
    restart_service
    ;;
  logs)
    view_logs
    ;;
  status)
    ./monitor.sh
    ;;
  update)
    update_and_deploy
    ;;
  *)
    echo "Penggunaan: $0 {start|stop|restart|logs|status|update}"
    exit 1
    ;;
esac
