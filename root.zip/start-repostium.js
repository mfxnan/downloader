const { spawn } = require("node:child_process");
const fs = require("node:fs");
const path = require("node:path");

const root = __dirname;

// Parser .env sederhana tanpa dependency eksternal
function loadEnv() {
  const envFile = path.join(root, ".env");
  if (!fs.existsSync(envFile)) return;
  const content = fs.readFileSync(envFile, "utf8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eqIdx = line.indexOf("=");
    if (eqIdx !== -1) {
      const key = line.slice(0, eqIdx).trim();
      let val = line.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      if (!process.env[key]) {
        process.env[key] = val;
      }
    }
  }
}

loadEnv();

const services = [
  {
    name: "web-repostium",
    cwd: path.join(root, "apps", "web-repostium"),
    env: {
      ...process.env,
      PORT: process.env.WEB_PORT || "4174",
      DOWNLOADER_INTERNAL_URL: process.env.DOWNLOADER_INTERNAL_URL || "http://127.0.0.1:8000",
    },
    retries: 0,
  },
  {
    name: "dl-repostium",
    cwd: path.join(root, "apps", "dl-repostium"),
    env: {
      ...process.env,
      PORT: process.env.DOWNLOADER_PORT || "8000",
    },
    retries: 0,
  },
];

const children = new Map();
let isShuttingDown = false;
const MAX_AUTO_RESTARTS = 10;
const RESTART_DELAY_MS = 2500;

function log(serviceName, message) {
  const time = new Date().toISOString().slice(11, 19);
  console.log(`[${time}] [${serviceName}] ${message}`);
}

function startService(service) {
  if (isShuttingDown) return;

  const child = spawn(process.execPath, ["server.js"], {
    cwd: service.cwd,
    env: service.env,
    stdio: ["inherit", "pipe", "pipe"],
    windowsHide: false,
  });

  children.set(service.name, child);

  child.stdout.on("data", (chunk) => {
    process.stdout.write(`[${service.name}] ${chunk}`);
  });

  child.stderr.on("data", (chunk) => {
    process.stderr.write(`[${service.name}] ${chunk}`);
  });

  child.on("error", (error) => {
    log(service.name, `Gagal dijalankan: ${error.message}`);
    triggerRestart(service);
  });

  child.on("exit", (code, signal) => {
    if (isShuttingDown) return;
    const reason = signal ? `signal ${signal}` : `kode exit ${code ?? 0}`;
    log(service.name, `Proses berhenti dengan ${reason}.`);
    triggerRestart(service);
  });
}

function triggerRestart(service) {
  if (isShuttingDown) return;

  if (service.retries >= MAX_AUTO_RESTARTS) {
    log(service.name, `Mencapai batas maksimal restart (${MAX_AUTO_RESTARTS}x). Berhenti mengulang.`);
    return;
  }

  service.retries += 1;
  log(service.name, `Mencoba auto-restart (${service.retries}/${MAX_AUTO_RESTARTS}) dalam ${RESTART_DELAY_MS / 1000} detik...`);

  setTimeout(() => {
    if (!isShuttingDown) {
      startService(service);
    }
  }, RESTART_DELAY_MS);
}

function stopAll(exitCode = 0) {
  if (isShuttingDown) return;
  isShuttingDown = true;
  console.log("\nMematikan semua layanan...");

  for (const [name, child] of children.entries()) {
    if (!child.killed) {
      log(name, "Mengirim sinyal SIGTERM...");
      child.kill("SIGTERM");
    }
  }

  setTimeout(() => {
    for (const [name, child] of children.entries()) {
      if (!child.killed) {
        log(name, "Proses belum berhenti, mematikan paksa (SIGKILL)...");
        try { child.kill("SIGKILL"); } catch {}
      }
    }
    process.exit(exitCode);
  }, 1200);
}

process.on("SIGINT", () => stopAll(0));
process.on("SIGTERM", () => stopAll(0));

console.log("==========================================");
console.log("      REPOSTIUM MULTI-SERVICE RUNNER      ");
console.log("==========================================");
for (const service of services) {
  console.log(`- Service: ${service.name} (Port: ${service.env.PORT})`);
  startService(service);
}
console.log("Tekan Ctrl+C untuk menghentikan semua layanan.\n");
