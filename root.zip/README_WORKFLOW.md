# 🚀 Panduan Workflow Server Repostium (Termux & Linux)

Dokumen ini menjelaskan alur kerja (*workflow*) baru yang sudah dioptimalkan untuk performa stabil, ringan, dan fleksibel terutama di lingkungan **Termux (Android)** dan **Linux/VPS**.

---

## 📁 Struktur Monorepo

```text
server/
├── apps/
│   ├── web-repostium/       # Portal Web utama (Port 4174)
│   └── dl-repostium/        # Downloader Media backend (Port 8000)
├── .env                     # Konfigurasi port & environment terpusat
├── .env.example             # Contoh template konfigurasi
├── ecosystem.config.js      # Konfigurasi Process Manager PM2 (Auto-restart & RAM limiter)
├── start-repostium.js       # Native multi-runner (Fallback tanpa PM2 dengan auto-retry)
├── termux-service.sh        # CLI pengontrol service untuk Termux (start/stop/restart/logs/update)
├── monitor.sh               # Dashboard monitor sistem & health check
├── package.json             # Root monorepo (npm workspaces)
└── start-repostium.bat      # Runner untuk pengujian di Windows
```

---

## ⚡ Fitur Utama Workflow Baru

1. **NPM Workspaces**:
   - Cukup jalankan `npm install` di root server, semua dependency sub-app terpasang otomatis.
2. **Centralized Environment (`.env`)**:
   - Port dan parameter penting diatur dari file `.env` di root.
3. **PM2 & Resilient Auto-restart**:
   - Dilengkapi `ecosystem.config.js` dengan batasan memori ramah Termux (`max_memory_restart: 150M-200M`).
   - Jika PM2 belum terpasang, `start-repostium.js` memiliki fallback auto-restart mandiri jika salah satu service crash.
4. **Internal Reverse Proxy & Single Port Access**:
   - Web server (`web-repostium`) sekarang mem-proxy request `/api/dl/*` langsung ke downloader backend.
   - Cloudflare Tunnel atau domain publik cukup mengarah ke port **4174**, tanpa perlu membuat 2 tunnel terpisah!
5. **Health Check Endpoints**:
   - `GET /health` di web-repostium (port 4174)
   - `GET /health` di dl-repostium (port 8000)
   - `GET /api/dl/health` via reverse proxy
6. **Termux Service Controller (`termux-service.sh`)**:
   - 1 script bash serbaguna untuk mengelola server.

---

## 📲 Panduan Menjalankan di Termux

### 1. Persiapan Awal di Termux
Pastikan paket dasar terpasang:
```bash
pkg update -y
pkg install nodejs-lts git curl tmux python -y

# Opsional tapi SANGAT direkomendasikan untuk stabilitas proses:
npm install -g pm2
```

### 2. Memasang Dependensi
Di folder proyek:
```bash
chmod +x termux-service.sh monitor.sh
npm install
```

### 3. Perintah Operasional
Gunakan `termux-service.sh`:
- **Menjalankan Server**:
  ```bash
  ./termux-service.sh start
  ```
- **Melihat Status & Health Check**:
  ```bash
  ./termux-service.sh status
  # atau
  ./monitor.sh
  ```
- **Melihat Log Realtime**:
  ```bash
  ./termux-service.sh logs
  ```
- **Restart Server**:
  ```bash
  ./termux-service.sh restart
  ```
- **Hentikan Server**:
  ```bash
  ./termux-service.sh stop
  ```
- **Update Otomatis (Git Pull + Install + Restart)**:
  ```bash
  ./termux-service.sh update
  ```

---

## 🌐 Menghubungkan ke Cloudflare Tunnel di Termux
Karena kini ada reverse proxy internal, Cloudflare Tunnel cukup membuka port web utama:
```bash
cloudflared tunnel --url http://127.0.0.1:4174
```
Semua rute web dan API downloader (`/api/dl/*`) dapat diakses melalui 1 URL Cloudflare yang sama.
