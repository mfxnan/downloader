#!/data/data/com.termux/files/usr/bin/bash

# ========================================================
# REPOSTIUM MONITOR & STATUS (TERMUX OPTIMIZED)
# ========================================================

clear
echo "=================================================="
echo "          REPOSTIUM SERVER MONITOR (TERMUX)       "
echo "=================================================="
echo

echo "[1. WAKTU & SISTEM]"
date
uptime
echo

echo "[2. STATUS PROSES / ENGINE]"
if command -v pm2 &>/dev/null && pm2 id web-repostium &>/dev/null; then
  echo "Engine Aktif : PM2 Process Manager"
  pm2 list
else
  echo "Engine Aktif : Native Process / tmux"
  if tmux has-session -t repostium 2>/dev/null; then
    echo "Session Repostium : [AKTIF] (tmux session: repostium)"
  else
    echo "Session Repostium : [TIDAK AKTIF]"
  fi

  if tmux has-session -t cloudflared 2>/dev/null; then
    echo "Cloudflare Tunnel : [AKTIF] (tmux session: cloudflared)"
  else
    echo "Cloudflare Tunnel : [TIDAK AKTIF]"
  fi
fi

echo
echo "[3. HEALTH CHECK ENDPOINTS (HTTP)]"
check_health() {
  local name="$1"
  local url="$2"
  local res
  res=$(curl -s -m 2 "$url" 2>/dev/null)
  if [[ -n "$res" ]] && echo "$res" | grep -q '"status":"ok"'; then
    echo "  - $name: [ONLINE / SEHAT] ($url)"
  else
    echo "  - $name: [OFFLINE / UNREACHABLE] ($url)"
  fi
}

# Baca PORT dari .env bila ada
WEB_PORT=4174
DL_PORT=8000
if [[ -f .env ]]; then
  WEB_PORT=$(grep -E '^WEB_PORT=' .env | cut -d '=' -f2 | tr -d ' "\r')
  DL_PORT=$(grep -E '^DOWNLOADER_PORT=' .env | cut -d '=' -f2 | tr -d ' "\r')
fi

check_health "Web Portal " "http://127.0.0.1:${WEB_PORT:-4174}/health"
check_health "Downloader " "http://127.0.0.1:${DL_PORT:-8000}/health"
check_health "Web Proxy  " "http://127.0.0.1:${WEB_PORT:-4174}/api/dl/health"

echo
echo "[4. MEMORI & PENYIMPANAN]"
if [[ -f /proc/meminfo ]]; then
  grep -E 'MemTotal|MemAvailable|MemFree|SwapTotal|SwapFree' /proc/meminfo
fi
echo
df -h "$HOME" 2>/dev/null || df -h .

echo
echo "[5. PROSES AKTIF (NODE & CLOUDFLARED)]"
ps -A -o PID,NAME,%CPU,%MEM 2>/dev/null | grep -E 'node|cloudflared|python' | grep -v grep || echo "Tidak ada proses yang berjalan."

echo
echo "=================================================="
echo "Perintah Cepat:"
echo "  - Restart Service : ./termux-service.sh restart"
echo "  - Cek Log Realtime: ./termux-service.sh logs"
echo "  - Update & Deploy : ./termux-service.sh update"
echo "=================================================="
