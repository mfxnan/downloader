const fs = require("node:fs");
const path = require("node:path");

function loadEnvFile(envPath) {
  const result = {};
  if (!fs.existsSync(envPath)) return result;
  const content = fs.readFileSync(envPath, "utf8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eqIdx = line.indexOf("=");
    if (eqIdx !== -1) {
      const key = line.slice(0, eqIdx).trim();
      let val = line.slice(eqIdx + 1).trim();
      if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
        val = val.slice(1, -1);
      }
      result[key] = val;
    }
  }
  return result;
}

const envConfig = loadEnvFile(path.join(__dirname, ".env"));

module.exports = {
  apps: [
    {
      name: "web-repostium",
      cwd: path.join(__dirname, "apps", "web-repostium"),
      script: "server.js",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "150M",
      restart_delay: 2000,
      env: {
        NODE_ENV: "production",
        PORT: envConfig.WEB_PORT || process.env.WEB_PORT || 4174,
        DOWNLOADER_INTERNAL_URL: envConfig.DOWNLOADER_INTERNAL_URL || process.env.DOWNLOADER_INTERNAL_URL || "http://127.0.0.1:8000"
      }
    },
    {
      name: "dl-repostium",
      cwd: path.join(__dirname, "apps", "dl-repostium"),
      script: "server.js",
      instances: 1,
      autorestart: true,
      watch: false,
      max_memory_restart: "200M",
      restart_delay: 2000,
      env: {
        NODE_ENV: "production",
        PORT: envConfig.DOWNLOADER_PORT || process.env.DOWNLOADER_PORT || 8000,
        YT_DLP_PATH: envConfig.YT_DLP_PATH || process.env.YT_DLP_PATH || ""
      }
    }
  ]
};
