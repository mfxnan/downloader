const homeView = document.querySelector("#home-view");
const articleView = document.querySelector("#article-view");
const headlineSection = document.querySelector("#headline-section");
const articleGrid = document.querySelector("#article-grid");
const topicPills = document.querySelector("#topic-pills");
const searchPanel = document.querySelector("#search-panel");
let activeCategory = "Semua";

const formatDate = (value) => new Intl.DateTimeFormat("id-ID", {
  day: "numeric", month: "long", year: "numeric", timeZone: "UTC"
}).format(new Date(`${value}T00:00:00Z`));

function escapeHtml(value) {
  return String(value).replace(/[&<>'"]/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  }[character]));
}

function renderPills() {
  const categories = [
    { label: "Berita", value: "Semua" },
    { label: "Nasional", value: "Bisnis" },
    { label: "Peristiwa", value: "Sains" },
    { label: "Teknologi", value: "Teknologi" },
    { label: "Gadget", value: "Gadget" }
  ];
  topicPills.innerHTML = categories.map((category) =>
    `<button class="topic-pill ${category.value === activeCategory ? "active" : ""}" data-category="${category.value}">${category.label}</button>`
  ).join("");
}

async function loadArticles(category = activeCategory, query = "") {
  const params = new URLSearchParams();
  if (category !== "Semua") params.set("category", category);
  if (query) params.set("q", query);
  const response = await fetch(`/api/articles${params.size ? `?${params}` : ""}`);
  if (!response.ok) throw new Error("Gagal memuat artikel");
  const articles = await response.json();
  renderArticles(articles);
}

function renderArticles(articles) {
  if (!articles.length) {
    headlineSection.innerHTML = "";
    articleGrid.innerHTML = '<div class="empty-state"><h3>Belum ada artikel</h3><p>Coba kategori atau kata kunci lain.</p></div>';
    return;
  }

  const featured = articles.find((article) => article.featured) || articles[0];
  headlineSection.innerHTML = `
    <article class="headline-card">
      <div class="headline-copy">
        <p class="eyebrow">${escapeHtml(featured.category)} · ${formatDate(featured.date)}</p>
        <h1>${escapeHtml(featured.title)}</h1>
        <p class="excerpt">${escapeHtml(featured.excerpt)}</p>
        <div class="article-meta"><strong>${escapeHtml(featured.author)}</strong><span class="meta-dot"></span><span>${escapeHtml(featured.readTime)}</span></div>
        <button class="read-link" data-article="${escapeHtml(featured.id)}">Baca cerita →</button>
      </div>
      <div class="headline-image"><img src="${escapeHtml(featured.image)}" alt="${escapeHtml(featured.title)}"></div>
    </article>`;

  const others = articles.filter((article) => article.id !== featured.id);
  articleGrid.innerHTML = others.map((article) => `
    <article class="article-card" data-article="${escapeHtml(article.id)}" tabindex="0">
      <div class="card-image"><img src="${escapeHtml(article.image)}" alt="${escapeHtml(article.title)}" loading="lazy"></div>
      <div class="card-copy">
        <span class="category-label">${escapeHtml(article.category)}</span>
        <h3>${escapeHtml(article.title)}</h3>
        <p class="excerpt">${escapeHtml(article.excerpt)}</p>
        <div class="article-meta"><strong>${escapeHtml(article.author)}</strong><span class="meta-dot"></span><span>${escapeHtml(article.readTime)}</span></div>
      </div>
    </article>`).join("");
}

async function openArticle(id) {
  const response = await fetch(`/api/articles/${encodeURIComponent(id)}`);
  if (!response.ok) return;
  const article = await response.json();
  homeView.hidden = true;
  articleView.hidden = false;
  searchPanel.hidden = true;
  articleView.innerHTML = `
    <button class="back-button" id="back-button">← Semua artikel</button>
    <header class="article-view-header">
      <p class="eyebrow">${escapeHtml(article.category)} · ${formatDate(article.date)}</p>
      <h1>${escapeHtml(article.title)}</h1>
      <p class="excerpt">${escapeHtml(article.excerpt)}</p>
      <div class="article-meta"><strong>${escapeHtml(article.author)}</strong><span class="meta-dot"></span><span>${escapeHtml(article.readTime)}</span></div>
    </header>
    <img class="article-hero" src="${escapeHtml(article.image)}" alt="${escapeHtml(article.title)}">
    <div class="article-body">${article.content.split(/\n\n+/).map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join("")}</div>`;
  window.scrollTo({ top: 0, behavior: "instant" });
  history.pushState({ article: id }, "", `#article/${encodeURIComponent(id)}`);
}

const staticPages = {
  about: {
    title: "Tentang REPOSTIUM",
    subtitle: "REPOSTIUM MEDIA - Dari Peristiwa Menjadi Informasi.",
    sections: [
      ["Tentang Kami", "REPOSTIUM MEDIA merupakan media informasi digital yang menyajikan berita, peristiwa aktual, informasi viral, serta berbagai isu yang menjadi perhatian masyarakat, baik dari tingkat daerah, nasional, maupun internasional. Dalam menjalankan pemberitaan, REPOSTIUM menggabungkan kurasi informasi dari berbagai sumber dengan peliputan mandiri di lapangan."],
      ["Apa yang Kami Sajikan?", "Kami menghadirkan Nasional, Daerah, Viral, Kriminal, Politik, dan Internasional. Informasi dihimpun dari laporan masyarakat, media sosial, sumber resmi, dokumen publik, narasumber, dan media pemberitaan untuk disajikan secara informatif, kontekstual, dan bertanggung jawab."],
      ["Kurasi dan Liputan Mandiri", "Kami menelusuri sumber dan menyusun ulang informasi berdasarkan konteks serta atribusi sumber. Untuk peristiwa tertentu, REPOSTIUM juga melakukan pengumpulan dokumentasi, pengamatan di lapangan, dan pencarian keterangan dari pihak yang relevan."],
      ["Visi", "Menjadi media informasi digital yang informatif, independen, dan bertanggung jawab dalam menyampaikan berbagai peristiwa serta perkembangan isu yang menjadi perhatian publik."],
      ["Misi", "• Menyajikan informasi yang aktual, relevan, dan mudah dipahami masyarakat.\n• Mengutamakan ketepatan informasi dan kejelasan sumber.\n• Mengembangkan kurasi informasi dan peliputan mandiri.\n• Memberikan konteks agar pembaca memahami peristiwa secara utuh.\n• Menghargai hak cipta, privasi, dan hak jawab pihak terkait.\n• Melakukan koreksi atau pembaruan apabila ditemukan kekeliruan."],
      ["Prinsip Kami", "REPOSTIUM berupaya membedakan fakta, pernyataan narasumber, dugaan, dan opini. Informasi yang belum terkonfirmasi tidak akan disajikan seolah-olah telah menjadi fakta. Kami mencantumkan sumber dan memberikan ruang bagi klarifikasi."]
    ]
  },
  term: {
    title: "Syarat dan Ketentuan",
    subtitle: "Selamat datang di REPOSTIUM MEDIA. Dengan mengakses website ini, pengunjung diharapkan membaca dan memahami ketentuan berikut.",
    sections: [
      ["1. Ketentuan Umum", "Website REPOSTIUM menyediakan informasi untuk kepentingan publik. Penggunaan website harus dilakukan secara wajar dan tidak bertentangan dengan hukum, hak orang lain, maupun ketentuan yang berlaku."],
      ["2. Penggunaan Konten", "Konten yang dibuat dan dimiliki REPOSTIUM dilindungi hak cipta dan hak kekayaan intelektual. Pengunjung tidak boleh menyalin, menerbitkan ulang, mendistribusikan, atau menggunakan konten secara komersial tanpa izin."],
      ["3. Konten Pihak Ketiga", "Sebagian foto, video, kutipan, dan informasi dapat berasal dari pihak ketiga. Hak atas materi tersebut tetap berada pada pemilik atau pihak yang berhak."],
      ["4. Informasi dari Pengunjung", "Materi kiriman harus disertai kewenangan pengiriman dan tidak boleh melanggar hukum, mengandung ancaman atau fitnah, atau melanggar hak pihak lain. Pengiriman tidak menjamin materi dipublikasikan."],
      ["5. Larangan", "Dilarang menggunakan website untuk aktivitas melanggar hukum, menyebarkan informasi palsu, mengganggu keamanan, melanggar hak cipta, atau menyebarkan data pribadi tanpa dasar."],
      ["6. Tautan Pihak Ketiga", "Website dapat memuat tautan layanan eksternal yang tidak berada di bawah kendali penuh REPOSTIUM. Penggunaan layanan tersebut tunduk pada ketentuan penyedia."],
      ["7. Batas Tanggung Jawab", "REPOSTIUM berupaya menjaga ketersediaan dan ketepatan informasi, tetapi tidak menjamin seluruh informasi selalu lengkap dan terbaru. Pengunjung bertanggung jawab atas penggunaan informasi."],
      ["8. Persetujuan", "Dengan menggunakan website REPOSTIUM, pengunjung dianggap telah membaca dan memahami Syarat dan Ketentuan ini. Terakhir diperbarui: 22 November 2026."]
    ]
  },
  disclaimer: {
    title: "Disclaimer",
    subtitle: "Seluruh informasi yang dipublikasikan melalui website REPOSTIUM disediakan untuk tujuan informasi dan pengetahuan publik.",
    sections: [
      ["1. Ketepatan Informasi", "REPOSTIUM berupaya menyajikan informasi secara akurat dan bertanggung jawab. Peristiwa dapat berubah seiring perkembangan baru, sehingga kami tidak menjamin seluruh informasi selalu lengkap atau mutakhir."],
      ["2. Sumber Informasi", "Konten dapat berasal dari peliputan mandiri, laporan masyarakat, sumber resmi, media sosial, dokumen publik, maupun media pemberitaan lain. Tanggung jawab atas materi asli berada pada pihak yang menerbitkan atau menyediakannya."],
      ["3. Dugaan dan Proses Hukum", "Informasi mengenai dugaan tindak pidana atau proses hukum tidak dimaksudkan sebagai penetapan kesalahan. Setiap pihak tetap memiliki hak klarifikasi dan perlakuan sesuai hukum."],
      ["4. Foto, Video, dan Hak Cipta", "Materi pihak ketiga dapat memiliki hak cipta. Pemilik hak dapat menghubungi REPOSTIUM untuk menyampaikan keberatan atau permintaan peninjauan."],
      ["5. Tautan Eksternal", "Kami tidak mengendalikan isi, kebijakan, keamanan, maupun perubahan pada website atau layanan pihak ketiga."],
      ["6. Penggunaan Informasi", "Informasi di website ini bukan pengganti nasihat profesional, keputusan resmi, atau dokumen pihak berwenang. Terakhir diperbarui: 22 November 2026."]
    ]
  },
  privacy: {
    title: "Kebijakan Privasi",
    subtitle: "REPOSTIUM MEDIA menghargai privasi pengunjung dan menjelaskan jenis informasi yang mungkin diproses serta cara penggunaannya.",
    sections: [
      ["1. Informasi yang Diproses", "Ketika mengakses website, platform atau layanan dapat memproses alamat IP, jenis perangkat dan browser, sistem operasi, halaman yang dikunjungi, waktu kunjungan, serta informasi teknis keamanan. Informasi yang dikirimkan sukarela dapat berupa nama, email, dan isi pesan."],
      ["2. Penggunaan Informasi", "Informasi digunakan untuk menjalankan dan menjaga fungsi website, menanggapi pertanyaan dan laporan, meninjau koreksi, menjaga keamanan, serta meningkatkan kualitas layanan."],
      ["3. Cookies", "Blogger dan layanan Google terkait dapat memanfaatkan cookies untuk fungsi teknis, keamanan, preferensi, analisis, atau layanan lainnya. Pengunjung dapat mengelola cookies melalui pengaturan browser."],
      ["4. Layanan Pihak Ketiga", "Google dan penyedia layanan pihak ketiga dapat memproses informasi sesuai fungsi dan kebijakan privasi mereka masing-masing."],
      ["5. Berbagi dan Penyimpanan Informasi", "REPOSTIUM tidak menjual informasi pribadi. Informasi dapat diteruskan apabila diperlukan untuk layanan, permintaan sah, keamanan, atau kewajiban hukum. Tidak ada sistem elektronik yang dijamin sepenuhnya bebas risiko."],
      ["6. Tautan Eksternal dan Hak Pengunjung", "Kebijakan ini tidak mengatur website eksternal. Pengunjung dapat menghubungi REPOSTIUM untuk pertanyaan mengenai informasi yang dikirimkan secara langsung. Terakhir diperbarui: 22 November 2026."]
    ]
  },
  faq: {
    title: "Pertanyaan Umum",
    subtitle: "Berikut pertanyaan yang sering diajukan mengenai REPOSTIUM MEDIA.",
    sections: [
      ["Apa itu REPOSTIUM?", "REPOSTIUM MEDIA merupakan media informasi digital yang menyajikan berita, peristiwa aktual, informasi viral, dan berbagai isu yang menjadi perhatian masyarakat."],
      ["Apakah REPOSTIUM mengunggah ulang konten?", "Tidak sepenuhnya. REPOSTIUM melakukan kurasi berbagai sumber sekaligus peliputan mandiri terhadap peristiwa tertentu."],
      ["Dari mana sumber informasi diperoleh?", "Sumber dapat berupa laporan masyarakat, media sosial, sumber resmi, narasumber, dokumen publik, media pemberitaan, serta hasil peliputan mandiri."],
      ["Bagaimana cara mengirim laporan?", "Hubungi kanal komunikasi resmi REPOSTIUM. Sertakan lokasi, waktu kejadian, deskripsi singkat, dan dokumentasi jika tersedia. Hindari mengirimkan informasi pribadi yang tidak relevan."],
      ["Apakah laporan pasti dipublikasikan?", "Tidak. Setiap laporan ditinjau berdasarkan relevansi, kelengkapan, kejelasan sumber, kepentingan publik, dan aspek keselamatan."],
      ["Bagaimana mengajukan koreksi?", "Sertakan tautan artikel, bagian yang dianggap keliru, serta bukti pendukung. REPOSTIUM akan meninjau permintaan sesuai kebijakan redaksi."],
      ["Apakah mengakses REPOSTIUM dikenakan biaya?", "Pengunjung dapat membaca konten yang tersedia tanpa biaya, kecuali ada layanan khusus yang memiliki ketentuan berbeda."]
    ]
  }
};

function openStaticPage(pageId) {
  const page = staticPages[pageId];
  if (!page) { showHome(); return; }
  homeView.hidden = true;
  articleView.hidden = false;
  searchPanel.hidden = true;
  articleView.innerHTML = `
    <button class="back-button" id="back-button">← Semua artikel</button>
    <header class="article-view-header static-page-header">
      <p class="eyebrow">REPOSTIUM</p>
      <h1>${escapeHtml(page.title)}</h1>
      <p class="excerpt">${escapeHtml(page.subtitle)}</p>
    </header>
    <div class="article-body static-page-body">${page.sections.map(([heading, text]) => `
      <section><h2>${escapeHtml(heading)}</h2><p>${escapeHtml(text).replace(/\n/g, "<br>")}</p></section>
    `).join("")}</div>`;
  window.scrollTo({ top: 0, behavior: "instant" });
}

function showHome() {
  articleView.hidden = true;
  homeView.hidden = false;
  loadArticles(activeCategory).catch(() => {});
  history.pushState({}, "", location.pathname);
  window.scrollTo({ top: 0, behavior: "instant" });
}

async function handleRoute() {
  const articleMatch = location.hash.match(/^#article\/([^/?#]+)/);
  const pageMatch = location.hash.match(/^#page\/([a-z]+)/);
  if (articleMatch) openArticle(decodeURIComponent(articleMatch[1])).catch(() => showHome());
  else if (pageMatch) openStaticPage(pageMatch[1]);
  else {
    articleView.hidden = true;
    homeView.hidden = false;
  }
}

document.addEventListener("click", (event) => {
  const articleElement = event.target.closest("[data-article]");
  if (articleElement) openArticle(articleElement.dataset.article);

  const categoryElement = event.target.closest("[data-category]");
  if (categoryElement && categoryElement.classList.contains("nav-link")) {
    document.querySelectorAll(".nav-link").forEach((link) => link.classList.toggle("active", link === categoryElement));
  }
  if (categoryElement) {
    activeCategory = categoryElement.dataset.category;
    renderPills();
    loadArticles(activeCategory).catch(() => {});
  }

  if (event.target.closest("#back-button")) showHome();
});

document.addEventListener("keydown", (event) => {
  const card = event.target.closest(".article-card");
  if (card && (event.key === "Enter" || event.key === " ")) openArticle(card.dataset.article);
});

document.querySelector("#search-button").addEventListener("click", () => {
  searchPanel.hidden = !searchPanel.hidden;
  if (!searchPanel.hidden) document.querySelector("#search-input").focus();
});

document.querySelector("#search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const query = document.querySelector("#search-input").value;
  showHome();
  loadArticles("Semua", query).catch(() => {});
});

document.querySelector("#sidebar-search-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const query = document.querySelector("#sidebar-search-input").value;
  activeCategory = "Semua";
  renderPills();
  loadArticles("Semua", query).catch(() => {});
});

const editor = document.querySelector("#editor-dialog");
document.querySelector("#open-editor").addEventListener("click", () => editor.showModal());
document.querySelector("#close-editor").addEventListener("click", () => editor.close());
document.querySelector("#cancel-editor").addEventListener("click", () => editor.close());

document.querySelector("#article-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const status = document.querySelector("#form-status");
  status.textContent = "Memublikasikan...";
  const payload = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/articles", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || "Artikel gagal dipublikasikan.");
    form.reset();
    editor.close();
    activeCategory = "Semua";
    renderPills();
    showHome();
  } catch (error) { status.textContent = error.message; }
});

window.addEventListener("hashchange", handleRoute);
renderPills();
loadArticles().catch(() => {
  headlineSection.innerHTML = '<div class="empty-state"><h3>Server belum siap</h3><p>Jalankan aplikasi dengan npm start.</p></div>';
});
handleRoute();
