const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

const port = Number(process.env.PORT) || 4174;
const downloaderInternalUrl = process.env.DOWNLOADER_INTERNAL_URL || "http://127.0.0.1:8000";
const publicDir = path.join(__dirname, "public");
const dataFile = path.join(__dirname, "articles.json");

function proxyToDownloader(targetPath, clientReq, clientRes) {
  try {
    const targetUrl = new URL(targetPath, downloaderInternalUrl);
    const headers = { ...clientReq.headers, host: targetUrl.host };
    
    const proxyReq = http.request(
      targetUrl,
      {
        method: clientReq.method,
        headers,
      },
      (proxyRes) => {
        clientRes.writeHead(proxyRes.statusCode || 500, proxyRes.headers);
        proxyRes.pipe(clientRes);
      }
    );

    proxyReq.on("error", (err) => {
      if (!clientRes.headersSent) {
        sendJson(clientRes, 502, {
          error: "Downloader service tidak dapat dihubungi (Bad Gateway).",
          detail: err.message,
        });
      }
    });

    clientReq.pipe(proxyReq);
  } catch (error) {
    if (!clientRes.headersSent) {
      sendJson(clientRes, 500, { error: "Proxy error: " + error.message });
    }
  }
}

const seedArticles = [
  {
    id: "ai-pengubah-kerja",
    title: "AI Mulai Mengubah Cara Kerja Industri Kreatif Indonesia",
    excerpt: "Studio desain dan media lokal mulai mengadopsi kecerdasan buatan untuk mempercepat riset, produksi, dan distribusi konten.",
    category: "Teknologi",
    author: "Redaksi Repostium",
    date: "2026-11-23",
    readTime: "5 menit",
    image: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1600&q=85",
    featured: true,
    content: "Industri kreatif Indonesia memasuki fase baru saat kecerdasan buatan tidak lagi dipandang sekadar alat otomatisasi. Banyak studio kini menggunakannya untuk riset awal, brainstorming, pengelompokan insight, dan iterasi produksi.\n\nMeski produktivitas meningkat, para kreator menekankan bahwa keputusan artistik dan nilai manusia tetap menjadi penentu utama. Alat AI paling berguna ketika membantu tim mengerjakan pekerjaan berulang, bukan menggantikan proses berpikir dan kolaborasi.\n\nPara pelaku usaha juga mulai membangun pedoman penggunaan, termasuk pemeriksaan fakta, perlindungan data klien, dan transparansi terhadap audiens. Langkah tersebut dinilai penting agar adopsi teknologi tetap bertanggung jawab."
  },
  {
    id: "startup-sirkular",
    title: "Ekonomi Sirkular Jadi Peluang Baru bagi Startup Indonesia",
    excerpt: "Pemanfaatan ulang material dan pengurangan limbah menghadirkan model bisnis yang lebih tangguh.",
    category: "Bisnis",
    author: "Nadia Putri",
    date: "2026-11-21",
    readTime: "4 menit",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=1200&q=85",
    featured: false,
    content: "Ekonomi sirkular berkembang dari konsep lingkungan menjadi strategi pertumbuhan. Startup mulai menyusun model bisnis berbasis pengumpulan material bekas, perbaikan produk, dan pemanfaatan kembali sumber daya.\n\nTeknologi digital mempermudah pelacakan rantai pasok dan pencocokan pasokan limbah dengan industri pengolah. Namun, tantangan utamanya tetap pada logistik, standar kualitas, dan kepastian permintaan.\n\nKebijakan daerah yang konsisten serta kemitraan dengan pelaku usaha besar diperkirakan dapat mempercepat skalabilitas model ini."
  },
  {
    id: "kamera-satelit",
    title: "Teknologi Kamera Satelit Membuka Pemantauan Lingkungan Lebih Detail",
    excerpt: "Citra resolusi tinggi membantu pihak daerah memantau perubahan lahan dan dampak bencana.",
    category: "Sains",
    author: "Raka Mahendra",
    date: "2026-11-20",
    readTime: "6 menit",
    image: "https://images.unsplash.com/photo-1446776811953-b23d57bd21aa?auto=format&fit=crop&w=1200&q=85",
    featured: false,
    content: "Ketersediaan citra satelit berfrekuensi pembaruan tinggi membantu pemerintah dan komunitas memahami perubahan lingkungan secara lebih cepat. Data tersebut dapat digunakan untuk memantau penutupan lahan, kualitas air, dan distribusi dampak bencana.\n\nPengolahan citra modern kini memanfaatkan model pembelajaran mesin untuk mengenali pola secara otomatis. Hasilnya perlu tetap diverifikasi agar tidak menimbulkan kesimpulan yang keliru di lapangan."
  },
  {
    id: "gadget-lipat",
    title: "Gadget Layar Lipat Mulai Masuk Segmen yang Lebih Terjangkau",
    excerpt: "Produsen menekan biaya produksi sambil mempertahankan ketahanan layar dan daya tahan baterai.",
    category: "Gadget",
    author: "Laras Wibowo",
    date: "2026-11-18",
    readTime: "3 menit",
    image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?auto=format&fit=crop&w=1200&q=85",
    featured: false,
    content: "Perangkat layar lipat tidak lagi hanya ditujukan bagi pasar premium. Efisiensi pabrikan engsel, panel, dan proses perakitan membuka jalan bagi model dengan harga yang lebih terjangkau.\n\nPengguna tetap perlu memperhatikan ketahanan lipatan, kualitas lapisan luar, dan ketersediaan dukungan perangkat lunak dalam jangka panjang."
  },
  {
    id: "literasi-digital",
    title: "Literasi Digital Jadi Kunci Mencegah Informasi Menyesatkan",
    excerpt: "Pemeriksaan silang sumber dan memahami konteks menjadi keterampilan penting bagi pengguna internet.",
    category: "Budaya",
    author: "Dimas Ardi",
    date: "2026-11-17",
    readTime: "4 menit",
    image: "https://images.unsplash.com/photo-1523995462485-3d171b5c8fa9?auto=format&fit=crop&w=1200&q=85",
    featured: false,
    content: "Arus informasi cepat menuntut pembaca memiliki kebiasaan verifikasi yang baik. Pemeriksaan tanggal, sumber asli, identitas penulis, dan konteks gambar dapat membantu mengurangi penyebaran konten menyesatkan.\n\nOrganisasi pendidikan dan komunitas digital juga mulai memasukkan latihan pemisahan fakta, opini, dan informasi yang belum terkonfirmasi ke dalam materi sehari-hari."
  }
];

function readArticles() {
  if (!fs.existsSync(dataFile)) {
    fs.writeFileSync(dataFile, JSON.stringify(seedArticles, null, 2));
  }
  return JSON.parse(fs.readFileSync(dataFile, "utf8"));
}

function writeArticles(articles) {
  fs.writeFileSync(dataFile, JSON.stringify(articles, null, 2));
}

function sendJson(response, status, payload) {
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  response.end(JSON.stringify(payload));
}

function parseJsonBody(request) {
  return new Promise((resolve, reject) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk;
      if (body.length > 2_000_000) {
        reject(new Error("Payload terlalu besar"));
        request.destroy();
      }
    });
    request.on("end", () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error("JSON tidak valid")); }
    });
  });
}

function slugify(value) {
  const base = value.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "artikel";
  return `${base}-${crypto.randomBytes(3).toString("hex")}`;
}

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
};

const server = http.createServer(async (request, response) => {
  const url = new URL(request.url, `http://${request.headers.host || "localhost"}`);

  if (url.pathname === "/health" && request.method === "GET") {
    sendJson(response, 200, {
      status: "ok",
      service: "web-repostium",
      uptime: process.uptime(),
      timestamp: new Date().toISOString()
    });
    return;
  }

  // Reverse proxy ke downloader service.
  if (url.pathname === "/api/dl/health") {
    proxyToDownloader("/health", request, response);
    return;
  }

  // /api/dl/* -> http://127.0.0.1:8000/api/*
  if (url.pathname.startsWith("/api/dl/")) {
    const strippedPath = url.pathname.replace(/^\/api\/dl/, "/api") + (url.search || "");
    proxyToDownloader(strippedPath, request, response);
    return;
  }

  if (url.pathname === "/api/articles" && request.method === "GET") {
    let articles = readArticles();
    const query = (url.searchParams.get("q") || "").trim().toLowerCase();
    const category = (url.searchParams.get("category") || "").trim().toLowerCase();
    if (query) articles = articles.filter((article) => `${article.title} ${article.excerpt} ${article.category}`.toLowerCase().includes(query));
    if (category && category !== "semua") articles = articles.filter((article) => article.category.toLowerCase() === category);
    sendJson(response, 200, articles);
    return;
  }

  if (url.pathname === "/api/articles" && request.method === "POST") {
    try {
      const payload = await parseJsonBody(request);
      const title = String(payload.title || "").trim();
      const content = String(payload.content || "").trim();
      if (!title || !content) { sendJson(response, 400, { error: "Judul dan isi artikel wajib diisi." }); return; }
      const articles = readArticles();
      const article = {
        id: slugify(title),
        title,
        excerpt: String(payload.excerpt || content).trim().slice(0, 180),
        category: String(payload.category || "Lainnya").trim(),
        author: String(payload.author || "Tim Repostium").trim(),
        date: new Date().toISOString().slice(0, 10),
        readTime: `${Math.max(1, Math.ceil(content.split(/\s+/).length / 220))} menit`,
        image: String(payload.image || "").trim() || "https://images.unsplash.com/photo-1495020689067-958852a77690?auto=format&fit=crop&w=1200&q=85",
        featured: false,
        content,
      };
      articles.unshift(article);
      writeArticles(articles);
      sendJson(response, 201, article);
    } catch (error) { sendJson(response, 400, { error: error.message }); }
    return;
  }

  if (url.pathname.startsWith("/api/articles/") && request.method === "GET") {
    const article = readArticles().find((item) => item.id === decodeURIComponent(url.pathname.split("/").pop()));
    if (!article) { sendJson(response, 404, { error: "Artikel tidak ditemukan." }); return; }
    sendJson(response, 200, article);
    return;
  }

  if (url.pathname.startsWith("/api/articles/") && request.method === "DELETE") {
    const id = decodeURIComponent(url.pathname.split("/").pop());
    const articles = readArticles();
    const next = articles.filter((item) => item.id !== id);
    if (next.length === articles.length) { sendJson(response, 404, { error: "Artikel tidak ditemukan." }); return; }
    writeArticles(next);
    sendJson(response, 200, { ok: true });
    return;
  }

  if (url.pathname.startsWith("/api/")) { sendJson(response, 404, { error: "Endpoint tidak ditemukan." }); return; }

  let relativePath = url.pathname === "/" ? "index.html" : decodeURIComponent(url.pathname.slice(1));
  let filePath = path.resolve(publicDir, relativePath);
  if (!filePath.startsWith(publicDir)) { response.writeHead(403); response.end("Forbidden"); return; }
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) filePath = path.join(publicDir, "index.html");
  fs.readFile(filePath, (error, data) => {
    if (error) { response.writeHead(404); response.end("Not found"); return; }
    response.writeHead(200, { "Content-Type": mimeTypes[path.extname(filePath)] || "application/octet-stream" });
    response.end(data);
  });
});

server.listen(port, "0.0.0.0", () => {
  console.log(`Repostium berjalan di http://localhost:${port}`);
});
