# Deployment Repostium di Termux dan Cloudflare Tunnel

Panduan ini mempertahankan dua aplikasi sebagai layanan terpisah.

- Website berita: `web-repostium`, port `4174`
- Media downloader: `dl-repostium`, port `8000`
- Website utama: domain utama Repostium
- Tool downloader: subdomain `dl.repostium.my.id`

## Struktur aplikasi

```text
apps/
  web-repostium/
    server.js
    articles.json
    public/
  dl-repostium/
    server.js
    public/
    requirements.txt
```

Backend tidak digabungkan. Setiap aplikasi memakai process dan port sendiri, sedangkan Cloudflare Tunnel mengarahkan hostname yang berbeda ke port Node.js yang sesuai.

## Persyaratan Termux

Jalankan pembaruan paket:

```sh
pkg update && pkg upgrade
pkg install nodejs python ffmpeg git cloudflared
```

Pastikan `yt-dlp` tersedia:

```sh
cd ~/apps/dl-repostium
python -m pip install -r requirements.txt
python -m yt_dlp --version
```

Sesuaikan lokasi folder di atas jika aplikasi berada di direktori lain.

## Menjalankan website berita

```sh
cd ~/apps/web-repostium
node server.js
```

Website berita tersedia lokal pada:

```text
http://127.0.0.1:4174
```

Data artikel disimpan di:

```text
apps/web-repostium/articles.json
```

Untuk otomatis menjalankan ulang saat file berubah, gunakan:

```sh
node --watch server.js
```

## Menjalankan media downloader

```sh
cd ~/apps/dl-repostium
node server.js
```

Downloader tersedia lokal pada:

```text
http://127.0.0.1:8000
```

Server downloader memakai port `8000` secara bawaan. Anda juga dapat mengatur port lain:

```sh
PORT=8000 node server.js
```

Downloader mendukung URL publik TikTok, Instagram, dan Facebook. Konten yang meminta login, privat, atau dilindungi tidak didukung.

## Menjalankan kedua aplikasi bersamaan

Gunakan dua terminal Termux.

Terminal 1:

```sh
cd ~/apps/web-repostium
node server.js
```

Terminal 2:

```sh
cd ~/apps/dl-repostium
node server.js
```

Biarkan kedua terminal aktif. Jika Termux Android menghentikan proses saat aplikasi ditutup, jalankan layanan dari sesi `tmux` atau gunakan `termux-wake-lock`.

Contoh menggunakan `tmux`:

```sh
pkg install tmux

tmux new -s repostium
cd ~/apps/web-repostium
node server.js
```

Tekan `Ctrl+B`, lalu `D` untuk detach. Buka sesi kedua:

```sh
tmux new -s dl-repostium
cd ~/apps/dl-repostium
node server.js
```

Kembali ke sesi yang sudah berjalan:

```sh
tmux attach -t repostium
tmux attach -t dl-repostium
```

## Login Cloudflare Tunnel

Di Termux, autentikasi Tunnel sekali:

```sh
cloudflared tunnel login
```

Buat tunnel:

```sh
cloudflared tunnel create repostium
```

Catat ID Tunnel yang ditampilkan.

Buat file konfigurasi di home Termux:

```sh
mkdir -p ~/.cloudflared
nano ~/.cloudflared/config.yml
```

Contoh konfigurasi:

```yaml
tunnel: TUNNEL_ID
credentials-file: /data/data/com.termux/files/home/.cloudflared/TUNNEL_ID.json

ingress:
  - hostname: repostium.my.id
    service: http://127.0.0.1:4174

  - hostname: dl.repostium.my.id
    service: http://127.0.0.1:8000

  - service: http_status:404
```

Ganti:

- `TUNNEL_ID` dengan ID tunnel sebenarnya
- `repostium.my.id` dengan domain utama jika berbeda
- Isi path `credentials-file` sesuai output Cloudflare atau jalur Termux sebenarnya

## Route DNS Cloudflare

Di dashboard Cloudflare, buka zona domain dan tambahkan DNS:

1. A atau CNAME untuk `repostium.my.id` menunjuk ke tunnel
2. CNAME untuk `dl.repostium.my.id` menunjuk ke tunnel

Jika menggunakan named tunnel, buat route melalui terminal:

```sh
cloudflared tunnel route dns repostium repostium.my.id
cloudflared tunnel route dns repostium dl.repostium.my.id
```

Pastikan kedua record berstatus Proxied.

## Menjalankan tunnel

```sh
cloudflared tunnel --config ~/.cloudflared/config.yml run repostium
```

Agar kembali otomatis saat Termux dimulai, jalankan tunnel melalui proses latar atau service yang tersedia di lingkungan Termux. Pastikan kedua aplikasi Node.js sudah aktif sebelum tunnel dijalankan.

## Verifikasi

Uji layanan lokal:

```sh
curl http://127.0.0.1:4174/
curl http://127.0.0.1:8000/
```

Uji domain publik:

```sh
curl -I https://repostium.my.id/
curl -I https://dl.repostium.my.id/
```

## Tautan dari website berita

Frontend berita sudah menyediakan tautan ke:

```text
https://dl.repostium.my.id/
```

Tautan berada pada header dan footer. Tidak ada perubahan API artikel yang diperlukan.

## Troubleshooting

### Subdomain downloader tidak terbuka

Periksa:

```sh
curl http://127.0.0.1:8000/
cloudflared tunnel info repostium
cloudflared tunnel route dns --help
```

Pastikan proses Node `dl-repostium` tetap berjalan dan record DNS sudah terhubung ke tunnel.

### Website utama tidak terbuka

Periksa port berita:

```sh
curl http://127.0.0.1:4174/
```

Pastikan konfigurasi Cloudflare mengarah ke `127.0.0.1:4174`, bukan `8000`.

### yt-dlp tidak ditemukan

```sh
cd ~/apps/dl-repostium
python -m pip install -U -r requirements.txt
python -m yt_dlp --version
```

Jika executable Python harus ditentukan, jalankan server dengan:

```sh
PYTHON=python node server.js
```

### Download gagal

Kondisi umum:

- URL bukan media publik
- Instagram meminta login
- Koneksi jaringan/Internet tidak stabil
- `ffmpeg` belum terpasang
- Ukuran media melebihi batas 300 MB

Uji proses `yt-dlp` langsung:

```sh
python -m yt_dlp --version
python -m yt_dlp --no-playlist --skip-download "URL_PUBLIK"
```

### Port sudah dipakai

Cari proses dan hentikan instance lama:

```sh
pkill -f "node server.js"
```

Hindari menjalankan `pkill -f` jika ada aplikasi Node lain yang perlu tetap aktif.

## Keamanan

- Jangan mengunggah cookie atau kredensial akun Instagram ke server.
- Jangan menyimpan API key atau credential di frontend.
- Gunakan hanya materi milik sendiri atau yang mendapat izin.
- Batasi ukuran unduhan dan jumlah proses aktif sesuai kapasitas Termux.
- Backup `articles.json` secara berkala.
